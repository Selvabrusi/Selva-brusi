const cartItems = [];

function addToCart(productId) {
    const product = getProductDetails(productId);
    cartItems.push(product);

    const cartList = document.getElementById("cart-items");
    const listItem = document.createElement("li");
    listItem.innerText = `${product.name} - $${product.price}`;
    cartList.appendChild(listItem);
}

